# Seconds2Website-Quickeasiest-Way-To-Make-Website-Online-Website-Builder-Build-on-PHP-JS-Jquery

VIDEO PREVIEW: http://bit.ly/Seconds2Website

"Seconds2Website" [featured: IRIS National Fair 2015] is a website builder application that enables users to create their website easily, in seconds &amp; free of cost build on PHP, JS, Jquery.
