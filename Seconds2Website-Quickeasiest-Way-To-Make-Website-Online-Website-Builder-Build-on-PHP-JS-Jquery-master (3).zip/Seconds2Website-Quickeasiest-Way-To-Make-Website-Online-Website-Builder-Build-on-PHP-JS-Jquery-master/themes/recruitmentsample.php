<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, maximum-scale=1">

<title>Recruitment</title>
<link rel="icon" href="favicon.png" type="image/png">
<link rel="shortcut icon" href="favicon.ico" type="img/x-icon">

<link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,800italic,700italic,600italic,400italic,300italic,800,700,600' rel='stylesheet' type='text/css'>

<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<link href="css/animate.css" rel="stylesheet" type="text/css">

<!--[if IE]><style type="text/css">.pie {behavior:url(PIE.htc);}</style><![endif]-->


<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/jquery-scrolltofixed.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.isotope.js"></script>
<script type="text/javascript" src="js/wow.js"></script>
<script type="text/javascript" src="js/classie.js"></script>
    <link href="slidemenu.css" rel="stylesheet"> 
    <link href="styles.css" rel="stylesheet">  
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.11.0/jquery-ui.min.js"></script>
    <script src="slidemenu.js"></script>
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="nano-spec.js"></script>

      <script src="jscolor.js"></script>
    <script src="script.js"></script>
    <script>
      window.onload = function() {
        document.getElementById("clickThis").addEventListener("click", function() { //about line 455
            var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            var email = document.getElementById("userEmail").value;
            if(emailRegex.test(email)) {
                var textToSay = "Your Sec2Web powered website is live!";
                var userContent = document.getElementById("toCopy").innerHTML;
                //var userContentHTML = userContent.html();
                //userContent.html(userContentHTML.replace("&", "and"));
                //window.location.href = "http://sec2web.net16.net/fileMaker.php?site=" + userContent; 
                //for small objects, the URL method
                if (window.XMLHttpRequest){
                  xmlhttp=new XMLHttpRequest();
                } else{
                  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
                }
                var currentWebsite = "http://sec2web.net16.net/";
                var PageToSendTo = currentWebsite + "fileMaker.php?";
                var locationPHP = currentWebsite + "fileMaker.php";
                var facebookURL = document.getElementById("fURL").value;
                //document.getElementById("facebook").href = facebookURL;
                var googlePlusURL = document.getElementById("gURL").value;
                //document.getElementById("google+").href = googlePlusURL;
                var twitterURL = document.getElementById("tURL").value;
                var name = document.getElementById("thename").value;    //about ln326
                //document.getElementById("twitter").href = twitterURL;
                //var VariablePlaceholder = "site=";
                //var UrlToSend = PageToSendTo + VariablePlaceholder + userContent;
                /*Use it only when xmlhttp.open is true, for JS when working*/
                xmlhttp.onreadystatechange = function() {
                  if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                    var box = "<br><b style=\"color:white\;\"><i class=\"fa fa-cog fa-spin\"></i></i> Your Site Is Live! </b><b style=\"font-size:11px; color:rgba(255, 255, 255, 0.55);\"><hr>Visit </b></div>";
                    var siteURL = xmlhttp.responseText;
                    document.getElementById("serverResponseText").innerHTML = box + siteURL;
                    //document.getElementById("demo").innerHTML = xhttp.responseText;
                  } else {
                    //window.alert("Try again!");
                  }
                };
                var argsToSend="site="+userContent+"&emaila="+email+"&uname="+name+"&fURL="+facebookURL+"&gURL="+googlePlusURL+"&tURL="+twitterURL;
                xmlhttp.open("POST", locationPHP, true);
                xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                xmlhttp.send(argsToSend);
                window.alert(textToSay);
            } else {
                window.alert("Invalid Email entered!");
                document.getElementById("userAlert").innerHTML="Invalid Email entered!";
            }
            //var userURL = ""; //try to use JSON. Or just email 'em
        }, false);
        document.getElementById("icon1").addEventListener("click", function() {

        }, false);
    }   
    </script>
</head>
<body>
<div style="overflow:hidden;">



<section class="main-section alabaster"><!--main-section alabaster-start-->

<div class="container">
      <div class="about">
        <h2 class="nameout">Seconds2Website</h2>
        <h6 class="aboutout">We hire interns year-round.</h6>
    </div>
        <div class="row">
            <div class="col-lg-4 col-sm-6 wow fadeInLeft delay-05s animated" style="visibility: visible; animation-name: fadeInLeft;">
                <div class="service-list">
                    <div class="service-list-col1">
                        <i class="fa-paw" id="mainIcon1"></i>
                    </div>
                    <div class="service-list-col2">
                        <h3 class="workout">Build Digital India.</h3>
                        <p class="workdataout">Spend a few months building
free websites for India.</p>
                    </div>
                </div>
                <div class="service-list">
                    <div class="service-list-col1">
                        <i class="fa-gear" id="mainIcon2"></i>
                    </div>
                    <div class="service-list-col2">
                        <h3 class="hobbiesout">Non-Profit.</h3>
                        <p class="hobbiesdataout">A non-profit with the benefits of a for-profit.</p>
                    </div>
                </div>
                <div class="service-list">
                    <div class="service-list-col1">
                        <i class="fa-apple" id="mainIcon3"></i>
                    </div>
                    <div class="service-list-col2">
                        <h3 class="achieveout">Love for Food.</h3>
                        <p class="achievedataout">Free snacks and drinks. Delicious fresh bread every Thursday..</p>
                    </div>
                </div>
                <div class="service-list">
                    <div class="service-list-col1" >
                        <i class="fa-medkit" id="mainIcon4"></i>
                    </div>
                    <div class="service-list-col2">
                        <h3 class="goalsout">NO SALARY JUST SALVATION.</h3>
                        <p class="goalsdataout">Join up and change the world.</p>
                    </div>
                </div>
            </div>
                <div class="col-lg-6 col-sm-5 wow fadeInUp delay-05s">
                <div class="form">
                    <input class="input-text" type="text" name="" value="Your Name *">
                    <input class="input-text" type="text" name="" value="Your E-mail *" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                    <textarea class="input-text text-area" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">Your Message *</textarea>
                    <input class="input-btn" type="submit" value="Apply Now">
                </div>  
            </div>
        
        </div>
    </div>
 </section>   

<section class="main-section client-part" id="client"><!--main-section client-part-start-->
    <div class="container">
        <b class="quote-right wow fadeInDown delay-03"><i class="fa fa-quote-right"></i></b>
        <div class="row">
            <div class="col-lg-12"><h4 class="quoteout client-part-haead wow fadeInDown delay-05 animated" style="visibility: visible; animation-name: fadeInDown;">People who are crazy enough to think they can change the world are the ones who really do!</h4>
            </div>
        </div>
       
    </div>
</section><!--main-section client-part-end-->



<div class="slide-menu">
    <ul class="menu-items">
        <li id="" class="menu-item" data-target="#Panel1" title="Home">
            <div class="menu-icon">
                <i class="fa fa-home"></i>
            </div>
            <div class="menu-content">                
                <span>Home</span>
            </div>
            <div class="menu-close">
                <i class="fa fa-times"></i>
            </div>
        </li>
           <li id="" class="menu-item" data-target="#Panel0" title="About">
            <div class="menu-icon">
                <i class="fa fa-comment"></i>
            </div>
            <div class="menu-content">                
                <span>About</span>
            </div>
            <div class="menu-close">
                <i class="fa fa-times"></i>
            </div>
        </li>
            <li id="" class="menu-item" data-target="#Panel2" title="TextList">
            <div class="menu-icon">
                <i class="fa fa-list"></i>
            </div>
            <div class="menu-content">                
                <span>TextList</span>
            </div>
            <div class="menu-close">
                <i class="fa fa-times"></i>
            </div>
        </li>
        <li id="SearchIcon" class="menu-item" data-target="#Panel3" title="Quotes">
            <div class="menu-icon">
                <i class="fa fa-quote-right"></i>
            </div>
            <div class="menu-content">                
                <span>Quotes</span>
            </div>
            <div class="menu-close">
                <i class="fa fa-times"></i>
            </div>
        </li>
      
        <li id="BugIcon" class="menu-item" data-target="#Panel4" title="Contact Form">
            <div class="menu-icon">
                 <i class="fa fa-envelope"></i>
            </div>
            <div class="menu-content">                
                <span>Contact Form</span>
            </div>
            <div class="menu-close">
                <i class="fa fa-times"></i>
            </div>
        </li>
         <li id="ShoppingIcon" class="menu-item" data-target="#Panel5" title="Link">
            <div class="menu-icon">
                <i class="fa fa-link"></i>
            </div>
            <div class="menu-content">                
                <span>Link</span>
            </div>
            <div class="menu-close">
                <i class="fa fa-times"></i>
            </div>
        </li>
         <li id="ShoppingIcon" class="menu-item" data-target="#Panel6" title="Typography">
            <div class="menu-icon">
                <i class="fa fa-font"></i>

            </div>
            <div class="menu-content">                
                <span>Typography</span>
            </div>
            <div class="menu-close">
                <i class="fa fa-times"></i>
            </div>
        </li>
      
           <li id="ShoppingIcon" class="menu-item" data-target="#Panel8" title="Icons">
            <div class="menu-icon">
                <i class="fa fa-folder-open-o"></i>
            </div>
            <div class="menu-content">                
                <span>Icons</span>
            </div>
            <div class="menu-close">
                <i class="fa fa-times"></i>
            </div>
               </li>
              <li id="ShoppingIcon" class="menu-item" data-target="#Panel9" title="Position">
            <div class="menu-icon">
                <i class="fa fa-puzzle-piece"></i>
            </div>
            <div class="menu-content">                
                <span>Position</span>
            </div>
            <div class="menu-close">
                <i class="fa fa-times"></i>
            </div>
        </li>
            <li style="background:black;" id="BugIcon" class="menu-item" data-target="#Panel7" title="Contact Form" >
            <div class="menu-icon">
                <i class="fa fa-paper-plane"></i>
            </div>
            <div class="menu-content">                
                <span>Submit</span>
            </div>
            <div class="menu-close">
                <i class="fa fa-times"></i>
            </div>
        </li>
    </ul>
        <div class="menu-panels">
           
           <div id="Panel1" class="menu-panel">
                     <div class="form"> 
 

                           <div style="overflow-y: auto; margin-top: 10%;" class="input-text index" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                          <b style="color:white;"><i class="fa fa-comment"></i> Images  <i style="color:rgba(255, 255, 255, 0.55);">  and  </i><i class="fa fa-quote-right"></i> Links </b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>Upload pictures and link your attachments to get professional work started.</b> </div>  


                           <div style="overflow-y: auto;" class="input-text index" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                          <b style="color:white;"><i class="fa fa-font"></i> Typography <i style="color:rgba(255, 255, 255, 0.55);">  and  </i><i class="fa fa-folder-open-o"></i> Icons </b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>Make your site look beautiful with awesome font typography and icons.</b> </div> 

                          <div style="overflow-y: auto;" class="input-text index" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                          <b style="color:white;"><i class="fa fa-puzzle-piece"></i> Position <i style="color:rgba(255, 255, 255, 0.55);">  &  </i><i class="fa fa-trash-o"></i> Style </b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>Play around with different sections, delete or resize the text.</b> </div> 
                          <div style="margin-top:28px;">
                           <a style="text-decoration:none; padding:14px 30px;"target="_blank" class="input-btn" href="https://www.youtube.com/user/harshitbatraVEVO" >Check out Sample </a>
                         </div>
                    </div>
                 </div>
                 <div id="Panel0" class="menu-panel">
                     <div class="form">
                       <textarea class="aboutinput input-text text-area"cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">Information about you/organisation..</textarea>
                      
                          <div style="overflow-y: auto;" class="input-text index" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <b style="color:white;"><i class="fa fa-cog fa-spin"></i></i> About</b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>Add information about you/your organistation which can impress the visitors.</b></div>  
                 </div>
               </div>


              <div id="Panel2" class="menu-panel">
                     <div class="form">
                         <input id="thename" class="nameinput input-text" type="text" name="" value="Name of Company." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><hr>
                              
                        <input class="workinput input-text" type="text" name="" value="Feature I." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <input class="workdatainput input-text" type="text" name="" value="About Feature I." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><hr>
                   <input class="hobbiesinput input-text" type="text" name="" value="Feature II." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <input class="hobbiedatainput input-text" type="text" name="" value="About Feature II." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><hr>
                   <input class="achieveinput input-text" type="text" name="" value="Feature III." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <input class="achievedatainput input-text" type="text" name="" value="About Feature III." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><hr>
                   <input class="goalsinput input-text" type="text" name="" value="Feature IV." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <input class="goalsdatainput input-text" type="text" name="" value="About Feature IV." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                    
                        
                 
                 </div>
               </div>
                    <div id="PanelA" class="menu-panel">
                     <div class="form">
                         <input class="nameinput input-text" type="text" name="" value="Name." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><hr>
                               <input class="statusinput input-text" type="text" name="" value="Status." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><hr>
                        <input class="workinput input-text" type="text" name="" value="Work." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <input class="workdatainput input-text" type="text" name="" value="About Work." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><hr>
                   <input class="hobbiesinput input-text" type="text" name="" value="Hobbies." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <input class="hobbiesdatainput input-text" type="text" name="" value="About Hobbies." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><hr>
                   <input class="achieveinput input-text" type="text" name="" value="Achievements." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <input class="achievedatainput input-text" type="text" name="" value="About Achievements." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><hr>
                   <input class="goalsinput input-text" type="text" name="" value="Goals." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <input class="goalsdatainput input-text" type="text" name="" value="About Goals." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                    
                        
                 
                 </div>
               </div>


         <div id="Panel3" class="menu-panel">
            <div class="form">
                  <textarea class="quoteinput input-text text-area"cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"  onblur="if(this.value=='')this.value=this.defaultValue;">Add Quote.</textarea>
                    <div style="overflow-y: auto;" class="input-text helptext" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><b style="color:white;font-size:15px;">HelpText</b><i style="color:rgba(255, 255, 255, 0.55);"> Quotes</i><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>
                     People who are crazy enough to think they can change the world are the ones who really do! <hr>
                        
                     You miss 100 percent of the shots you never take. <hr>
                     Be the change you wish to see in the world. <hr>
                     Everyone is a genius at least once a year. The real geniuses simply have their bright ideas closer together. <hr>
                     People often say that motivation does not last. Well, neither does bathing, so we recommend it daily. <hr>
                     Success is going from failure to failure without losing your enthusiasm. <hr>
                     The journey of a thousand miles begins with one step. <hr>
                     Dream big and dare to fail. <hr>
                     What you do speaks so loudly that I cannot hear what you say. <hr>
                     Tough times never last, but tough people do. <hr>
                     There is only one success: to be able to spend your life in your own way.<hr>
                     The best way out is always through. <hr>
                     The power of imagination makes us infinite.<hr>
                     Make each day your masterpiece. <hr>
                     The best dreams happen when you’re awake. <hr>
                     Once you choose hope, anything’s possible. <hr>
                     Believe and act as if it were impossible to fail.<hr>
                     Don’t count the days, make the days count.<hr>
                     The difference between ordinary and extraordinary is that little extra. <hr>
                     You must not only aim right, but draw the bow with all your might.<hr>
                     Don’t wait. The time will never be just right.<hr>
                     Everything you’ve ever wanted is on the other side of fear.<hr>
                     It is never too late to be what you might have been. <hr>
                     There are no traffic jams along the extra mile.<hr>
                     Do what you can, where you are, with what you have. Just do it.<hr>
                     The more I want to get something done, the less I call it work. <hr>
                     Your imagination is your preview of life’s coming attractions. <hr>
                     Do what you love and the money will follow.<hr>
                     The harder I work, the luckier I get. <hr>
                     If you can’t outplay them, outwork them. <hr>
                     The best way to predict the future is to invent it.<hr>
                     Champions keep playing until they get it right.<hr>
                     Change your thoughts and you change your world.<hr>
                     It’s not whether you get knocked down, it’s whether you get up.



      
                     </b>
                    </div>               
         </div>
     </div>




      
             <div id="Panel4" class="menu-panel">
               <div class="form">
                   <input class="input-text" type="text" name="" value="Add Email." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                    <textarea class="input-text text-area" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">Add Work Address.</textarea>
                     <div style="overflow-y: auto;" class="input-text index" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <b style="color:white;"><i class="fa fa-cog fa-spin"></i></i> Contact Details </b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>Add accurate contact details so that your viewers can find you & get intouch with you. All mails will be sent at your mail.</b></div>  
                </div>
            </div>

      
          <div id="Panel5" class="menu-panel">            

            <div class="form">
                  <input class="input-text" type="text" name="" value="Facebook Link." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" id="fURL">
                  <input class="input-text" type="text" name="" value="Google+ Link." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" id="gURL">
                  <input class="input-text" type="text" name="" value="Twitter Link." onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" id="tURL">                  
                </div>        
        </div>

                <div id="Panel6" class="menu-panel">
                <div class="form">            
                   <button  style="margin-top:10px;"  class="input-btn jscolor {valueElement:'chosen-value', onFineChange:'subhead(this)'}"><a style="margin:auto;text-decoration:none;">SubHeading</a>              
                  </button>

                  <button  style="margin-top:10px;"  class="input-btn jscolor {valueElement:'chosen-value', onFineChange:'head(this)'}"><a style="margin:auto;text-decoration:none;">Heading</a>      
                  </button>
                  <button style="margin-top:10px;" class="input-btn jscolor {valueElement:'chosen-value', onFineChange:'about(this)'}"><a style="margin:auto;text-decoration:none;">About</a> 
                    </button>   
                     <button style="margin-top:10px;" class="input-btn jscolor {valueElement:'chosen-value', onFineChange:'para(this)'}"><a style="margin:auto;text-decoration:none;">Paragraph</a> 
                    </button>        
                  <button style="margin-top:10px;" class="input-btn jscolor {valueElement:'chosen-value', onFineChange:'quote(this)'}"><a style="margin:auto;text-decoration:none;">Quote</a> 
                    </button>
                          <div style="overflow-y: auto; margin: 20px auto;" class="input-text index" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <b style="color:white;"><i class="fa fa-cog fa-spin"></i></i> Change Color</b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr> Change the font-color to the desired font color just with a click.</b></div>   
                 </div>
            </div>

             <div id="Panel7" class="menu-panel">
               <div class="form">
                   <input class="input-text" type="text" name="" value="Insert Email* " onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;" id="userEmail">
              
                     <div style="overflow-y: auto;" class="input-text index" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <b style="color:white;"><i class="fa fa-cog fa-spin"></i></i> Final Submit </b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>Its mandatory to add the email address so that we can send you your site details.</b></div>  
                  <div style="overflow-y: auto;" class="input-text index" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <b style="color:white;"><i class="fa fa-cog fa-spin"></i></i> NOTE </b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>Make sure you are done with your edits before hitting 'Submit' for processing.</b></div> 
                  <!--<form id="hiddenF" enctype="multipart/form-data" action="http://www.sec2web.com/fileMaker.php" method="post">
                    <input type="text" name="site" id="textToCopy"/>
                    <input style=" margin-top: 5%; background:black;" class="input-btn" type="submit" value="Submit" id="clickThis">
                  </form>-->
                <button style=" margin-top: 5%; background:black;" class="input-btn" id="clickThis">Submit</button>
                <div id="serverResponseText"></div>
                </div>
            </div>


             <div id="Panel8" class="menu-panel">
           <div class="form">            
              <div style="overflow-y: auto;" class="input-text icon" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;"><b style="color:white;font-size:15px;">IconsSet</b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>
              <span>
                      <button class="input-icn"><i class="fa fa-apple"></i></button>
     <button class="input-icn"><i class="fa fa-camera"></i></button>
  <button class="input-icn"><i class="fa fa-mobile-phone"></i></button>
  <button class="input-icn"><i class="fa fa-laptop"></i></button>
      <button class="input-icn"><i class="fa fa-photo "></i></button>
    <button class="input-icn"><i class="fa fa-windows"></i></button>
       <button class="input-icn"><i class="fa fa-bomb"></i></button>
     <button class="input-icn"><i class="fa fa-play"></i></button>
                <button class="input-icn"><i class="fa fa-quote-left "></i></button>
  <button class="input-icn"><i class="fa fa-smile-o"></i></button>
 <button class="input-icn"><i class="fa fa-twitter"></i></button>
  <button class="input-icn"><i class="fa fa-wechat"></i></button>

                    <button class="input-icn" id="icon1"><i class="fa fa-calendar" id="iconI1"></i></button>                
          
                <button class="input-icn" id="icon4"><i class="fa fa-check"></i></button>                
            <button class="input-icn" id="icon5"><i class="fa fa-coffee" id="iconI5"></i></button>
                <button class="input-icn" id="icon6"><i class="fa fa-cubes" id="iconI6"></i></button>
                         
            <button class="input-icn" id="icon8"><i class="fa fa-flask"></i></button>
                <button class="input-icn" id="icon9"><i class="fa fa-bolt"></i></button>
                <button class="input-icn" id="icon10"><i class="fa fa-headphones"></i></button>                
            <button class="input-icn" id="icon11"><i class="fa fa-laptop"></i></button>
                <button class="input-icn" id="icon12"><i class="fa fa-mobile"></i></button>
                <button class="input-icn" id="icon13"><i class="fa fa-thumb-tack"></i></button>                
            <button class="input-icn" id="icon14"><i class="fa fa-star-o"></i></button>
                <button class="input-icn" id="icon15"><i class="fa fa-angle-double-right"></i></button>





                <!-- ICONS START -->


                <button class="input-icn"><i class="fa fa-ambulance"></i></button>
              
                <button class="input-icn"><i class="fa fa-arrow-circle-left"></i></button>
                <button class="input-icn"><i class="fa fa-arrow-circle-o-up"></i></button>
                <button class="input-icn"><i class="fa fa-arrow-left"></i></button>
                <button class="input-icn"><i class="fa fa-bell"></i></button>
       
                <button class="input-icn"><i class="fa fa-book "></i></button>
                
           
                <button class="input-icn"><i class="fa fa-caret-square-o-right"></i></button>
               
          
                <button class="input-icn"><i class="fa fa-cloud "></i></button>
                <button class="input-icn"><i class="fa fa-comment"></i></button>
          
                <button class="input-icn"><i class="fa fa-cut"></i></button>
             
                <button class="input-icn"><i class="fa fa-dot-circle-o "></i></button>
                <button class="input-icn"><i class="fa fa-envelope-o"></i></button>
                <button class="input-icn"><i class="fa fa-euro"></i></button>
                <button class="input-icn"><i class="fa fa-exclamation-triangle"></i></button>
                <button class="input-icn"><i class="fa fa-fast-backward"></i></button>                
                <button class="input-icn"><i class="fa fa-female"></i></button>
                <button class="input-icn"><i class="fa fa-file-movie-o"></i></button>
                <button class="input-icn"><i class="fa fa-file-picture-o"></i></button>                
                <button class="input-icn"><i class="fa fa-file-text-o"></i></button>
                <button class="input-icn"><i class="fa fa-google"></i></button>
                <button class="input-icn"><i class="fa fa-hand-o-left "></i></button>
               
                <button class="input-icn"><i class="fa fa-header"></i></button>
                
                <button class="input-icn"><i class="fa fa-microphone"></i></button>
              
                <button class="input-icn"><i class="fa fa-pencil "></i></button>
                <button class="input-icn"><i class="fa fa-phone"></i></button>
                <button class="input-icn"><i class="fa fa-print"></i></button>
                <button class="input-icn"><i class="fa fa-qrcode"></i></button>
                <button class="input-icn"><i class="fa fa-quote-right"></i></button>
                <button class="input-icn"><i class="fa fa-refresh"></i></button>
                <button class="input-icn"><i class="fa fa-search"></i></button>
                <button class="input-icn"><i class="fa fa-send"></i></button>
            
                <button class="input-icn"><i class="fa fa-taxi"></i></button>
                <button class="input-icn"><i class="fa fa-user"></i></button>
                <button class="input-icn"><i class="fa fa-volume-off"></i></button>
            
                <button class="input-icn"><i class="fa fa-automobile"></i></button>
                <button class="input-icn"><i class="fa fa-beer"></i></button>
       
                <button class="input-icn"><i class="fa fa-calendar-o  "></i></button>
                <button class="input-icn"><i class="fa fa-camera-retro"></i></button>
              
                <button class="input-icn"><i class="fa fa-file-video-o"></i></button>
                <button class="input-icn"><i class="fa fa-film"></i></button>
       
                <button class="input-icn"><i class="fa fa-folder"></i></button>
                <button class="input-icn"><i class="fa fa-gamepad"></i></button>
              
                <button class="input-icn"><i class="fa fa-google-plus"></i></button>
                <button class="input-icn"><i class="fa fa-git-square"></i></button>
                <button class="input-icn"><i class="fa fa-institution"></i></button>
                <button class="input-icn"><i class="fa fa-map-marker"></i></button>
              
                <button class="input-icn"><i class="fa fa-question"></i></button>
               
                <button class="input-icn"><i class="fa fa-youtube"></i></button>
                <button class="input-icn"><i class="fa fa-car"></i></button>
                <button class="input-icn"><i class="fa fa-exclamation "></i></button>
                <button class="input-icn"><i class="fa fa-magic"></i></button>
               
          
            
                <button class="input-icn"><i class="fa fa-skype"></i></button>
                <button class="input-icn"><i class="fa fa-smile-o"></i></button>
                <button class="input-icn"><i class="fa fa-suitcase"></i></button>
                <button class="input-icn"><i class="fa fa-unlock "></i></button>
               
            
                <button class="input-icn"><i class="fa fa-yahoo"></i></button>
           
                <button class="input-icn"><i class="fa fa-angle-double-up"></i></button>
                <button class="input-icn"><i class="fa fa-arrow-down"></i></button>
                
         
                <button class="input-icn"><i class="fa fa-building-o"></i></button>
                
                <button class="input-icn"><i class="fa fa-cubes"></i></button>
                <button class="input-icn"><i class="fa fa-desktop"></i></button>
                <button class="input-icn"><i class="fa fa-facebook-square"></i></button>
            
                <button class="input-icn"><i class="fa fa-globe"></i></button>
                <button class="input-icn"><i class="fa fa-hand-o-down"></i></button>
             
                <button class="input-icn"><i class="fa fa-male "></i></button>
           
              
                <button class="input-icn"><i class="fa fa-tablet"></i></button>
                <button class="input-icn"><i class="fa fa-tree"></i></button>
                <button class="input-icn"><i class="fa fa-truck "></i></button>
               
           
              
                <button class="input-icn"><i class="fa fa-wheelchair"></i></button>
                <!-- ICONS END -->
                </span>
                  </b> </div>

                    <div style="overflow-y: auto; margin: 30px auto;" class="input-text index" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                 <b style="color:white;"><i class="fa fa-cog fa-spin"></i></i> Select and Replace</b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>Click the icon you want to replace, then use the choose the desired one from IconSet.</b></div>                         
      

          </div>
           </div>
       <div id="Panel9" class="menu-panel">
              <div class="form">
                        <div id="navArrows">
              <button id="centre" class="input-icn" style="  position: absolute;
    right: 63px;
    top: 70px;
    font-size:25px;"> <i class="fa fa-puzzle-piece"></i></button>
            <button id="left" class="navigationArrow input-btn">&larr;</button>
            <button id="up" class="navigationArrow input-btn">&uarr;</button>

            <button id="right" class="navigationArrow input-btn">&rarr;</button>
            <button id="down" class="navigationArrow input-btn">&darr;</button>
        </div>
        <div >    <button class="input-icn" style="width:43.5%;" ><i class="fa fa-arrow-up inc"></i></button>
                    <button class="input-icn" style="width:43.5%;"><i class="fa fa-arrow-down dec"></i></button>  
            <button class="input-btn" style="background: black; margin: 0px auto;" id="deleteButton">Delete</button>
        </div>
         <div style="overflow-y: auto; margin: 20px auto;" class="input-text index" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                  <b style="color:white;"><i class="fa fa-cog fa-spin"></i></i> Select and Play</b><b style="font-size:11px; color:rgba(255, 255, 255, 0.55);"><hr>Select the element to reposition it, increase font size and delete the elements.</b></div>
                    </div>      
               </div>        
            </div>      
       </div>      
    </div>
</div>
<script type="text/javascript">
window.jQuery || document.write('<script src="js/jquery-2.1.4.js"><\/script>');
    $(function() {
        $(".slide-menu").slidemenu();
    });


  $('.nameinput').keyup(function(event) {
    newText = event.target.value;
    $('.nameout').text(newText);
  });
    $('.namedatainput').keyup(function(event) {
    newText = event.target.value;
    $('.namedataout').text(newText);
  });

  $('.workinput').keyup(function(event) {
    newText = event.target.value;
    $('.workout').text(newText);
  });

  $('.workdatainput').keyup(function(event) {
    newText = event.target.value;
    $('.workdataout').text(newText);
  });

    $('.achieveinput').keyup(function(event) {
    newText = event.target.value;
    $('.achieveout').text(newText);
  });
      $('.achievedatainput').keyup(function(event) {
    newText = event.target.value;
    $('.achievedataout').text(newText);
  });

   $('.statusinput').keyup(function(event) {
    newText = event.target.value;
    $('.statusout').text(newText);
  });

    $('.hobbiesinput').keyup(function(event) {
    newText = event.target.value;
    $('.hobbiesout').text(newText);
  }); 

 $('.hobbiesdatainput').keyup(function(event) {
    newText = event.target.value;
    $('.hobbiesdataout').text(newText);
  });
  
  $('.goalsinput').keyup(function(event) {
    newText = event.target.value;
    $('.goalsout').text(newText);
  }); 

 $('.goalsdatainput').keyup(function(event) {
    newText = event.target.value;
    $('.goalsdataout').text(newText);
  });    

  $('.fbinput').keyup(function(event) {
    newText = event.target.value;
    $('.fbout').text(newText);
  });

  $('.instainput').keyup(function(event) {
    newText = event.target.value;
    $('.instaout').text(newText);
  });

  $('.gplusinput').keyup(function(event) {
    newText = event.target.value;
    $('.gplusout').text(newText);
  });

  $('.aboutinput').keyup(function(event) {
    newText = event.target.value;
    $('.aboutout').text(newText);
  });
  
  $('.quoteinput').keyup(function(event) {
    newText = event.target.value;
    $('.quoteout').text(newText);
  });



//function para(picker) { document.getElementsByTagName('p')[0].style.color = '#' + picker.toString()}
function para(picker) {
    var colorName = picker.toString();
    var abcxyz = document.getElementsByTagName('p');
    for(var count = 0; count < abcxyz.length; count++) {
        abcxyz[count].style.color = '#' + colorName;
    }
}
function about(picker) {
    var colorName = picker.toString();
    var abcxyz = document.getElementsByTagName('h6');
    for(var count = 0; count < abcxyz.length; count++) {
        abcxyz[count].style.color = '#' + colorName;
    }
}
function head(picker) {
    var colorName = picker.toString();
    var abcxyz = document.getElementsByTagName('h2');
    for(var count = 0; count < abcxyz.length; count++) {
        abcxyz[count].style.color = '#' + colorName;
    }
}
function subhead(picker) {
    var colorName = picker.toString();
    var abcxyz = document.getElementsByTagName('h3');
    
    for(var count = 0; count < abcxyz.length; count++) {
        abcxyz[count].style.color = '#' + colorName;
    }
}
function quote(picker) {
    var colorName = picker.toString();
    var abcxyz = document.getElementsByTagName('h4');
    
    for(var count = 0; count < abcxyz.length; count++) {
        abcxyz[count].style.color = '#' + colorName;
    }
}
function changeIconColour(picker) { // rgb(255, 77, 77);
    var colorName = picker.toString();
    var abcxyz = document.getElementsByTagName('i');
    for(var count = 0; count < abcxyz.length; count++) {
        abcxyz[count].style.color = '#' + colorName;
    }
}



    /*let's see the effects - none till now
    $(document).ready(function(e) {
        $('#test').scrollToFixed();
        $('.res-nav_click').click(function(){
            $('.main-nav').slideToggle();
            return false    
        });        
    });*/



    wow = new WOW(
      {
        animateClass: 'animated',
        offset:       100
      }
    );
    wow.init();
    document.getElementById('').onclick = function() {
      var section = document.createElement('section');
      section.className = 'wow fadeInDown';
      this.parentNode.insertBefore(section, this);
    };

    $(window).load(function(){
        
        $('.main-nav li a').bind('click',function(event){
            var $anchor = $(this);
            
            $('html, body').stop().animate({
                scrollTop: $($anchor.attr('href')).offset().top - 102
            }, 1500,'easeInOutExpo');
            /*
            if you don't want to use the easing effects:
            $('html, body').stop().animate({
                scrollTop: $($anchor.attr('href')).offset().top
            }, 1000);
            */
            event.preventDefault();
        });
    })

$(window).load(function(){
  
  
  var $container = $('.portfolioContainer'),
      $body = $('body'),
      colW = 375,
      columns = null;
  
  $container.isotope({
    // disable window resizing
    resizable: true,
    masonry: {
      columnWidth: colW
    }
  });
  
  $(window).smartresize(function(){
    // check if columns has changed
    var currentColumns = Math.floor( ( $body.width() -30 ) / colW );
    if ( currentColumns !== columns ) {
      // set new column count
      columns = currentColumns;
      // apply width to container manually, then trigger relayout
      $container.width( columns * colW )
        .isotope('reLayout');
    }
    
  }).smartresize(); // trigger resize to set container width
  $('.portfolioFilter a').click(function(){
        $('.portfolioFilter .current').removeClass('current');
        $(this).addClass('current');
 
        var selector = $(this).attr('data-filter');
        $container.isotope({
            
            filter: selector,
         });
         return false;
    });
  
});

</script>
</body>
</html>